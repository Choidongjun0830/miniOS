
// include/linux/sched.h
//SSU struct task_struct {

void minisystem();
void userInfo();
