#include <stdio.h>
#include <stdlib.h>

void minisystem()
{
    printf("minisystem\n");
}

void userInfo() 
{
    printf("20192645 Choi Dongjun\n");
}
